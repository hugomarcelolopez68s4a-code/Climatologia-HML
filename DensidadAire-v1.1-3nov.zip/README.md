# Densidad del aire

App Android nativa (Kotlin + Jetpack Compose) para calcular la densidad del aire en el lugar de vuelo, con viento por altura, Kp, sol, luna, pronóstico, mapa de radar y brújula. Viene configurada con **Formosa** y **San Salvador de Jujuy** como lugares favoritos.

## Cómo obtener el APK (se compila en GitHub)

1. Subí este proyecto a tu repositorio, rama `main`.
2. Entrá a la pestaña **Actions**. El flujo **Compilar APK** arranca solo con cada subida (también podés lanzarlo con *Run workflow*).
3. Cuando termine, abrí la ejecución y descargá el artefacto **DensidadAire-APK** (un zip con el `.apk`).
4. Para tener un enlace de descarga directa en **Releases**, creá una etiqueta que empiece con `v`:
   ```
   git tag v1.0 && git push origin v1.0
   ```
5. Copiá el `.apk` al teléfono e instalalo (hay que permitir instalar apps de orígenes desconocidos). Es un APK de depuración firmado con la clave de prueba de Android, sirve para uso personal.

Si la compilación falla, abrí el paso que quedó en rojo y copiá el error: casi siempre se corrige con un cambio de una línea.

## Qué hace

| Pestaña | Contenido |
|---|---|
| Resumen | Altitud del sitio y altura de vuelo (se cargan a mano o automáticas). Densidad del aire, % respecto de la atmósfera estándar y del nivel del mar, altitud densidad, temperatura, humedad, punto de rocío, presión, viento y ráfagas. |
| Viento | Velocidad, dirección, temperatura y densidad a 10 (suelo), 20, 40, 60, 80, 100, 120 y 180 m, más las alturas extra que cargues a mano (para montaña). Unidades km/h, m/s o nudos. |
| Pronóstico | 72 horas desde la hora elegida: cielo, lluvia, nubes, viento a 10 y 120 m, ráfagas, visibilidad y CAPE. |
| Cielo | Amanecer y atardecer, fase de la Luna a la hora elegida, índice Kp de NOAA actual y previsto. |
| Mapa | Mapa con radar de lluvia animado de las últimas 2 horas y capa opcional de cobertura de radar. |
| Brújula | Rumbo magnético y verdadero (con declinación), y la dirección del viento marcada en el dial. |
| Fotos | Sacás una o varias fotos del lugar y una IA las compara con los datos del pronóstico (ver abajo). |
| Ajustes | Tema automático, claro u oscuro (en azul) y clave de API para el análisis de fotos. |

## Análisis de fotos con IA

1. En **Ajustes** elegí el proveedor y cargá su clave de API:
   - **Gemini** (por defecto, modelo `gemini-3.8-flash`): la clave se crea gratis en Google AI Studio y tiene nivel gratuito con límites de uso. En ese nivel Google puede usar lo que enviás para mejorar sus productos.
   - **Claude** (modelo `claude-sonnet-5-5`): la clave se crea en la Claude Console y la API se cobra aparte de tu plan de Claude.
   Si el nombre de un modelo deja de existir, cambialo en ese mismo lugar.
2. En **Fotos** sacá las fotos, elegí hasta 4 y tocá *Analizar*.
3. La app manda las fotos y los datos del modelo a esa hora (cielo, nubosidad, lluvia, visibilidad, viento, temperatura, humedad) a la API de Claude, y muestra un veredicto (coincide, coincide en parte, no coincide, no evaluable) con el detalle por tema.

Cosas a tener en cuenta: la clave se guarda sin cifrar en el teléfono; las fotos salen del teléfono hacia el proveedor elegido solo cuando tocás *Analizar*; y una foto no sirve para medir temperatura, presión ni humedad, por eso esos puntos suelen quedar como «no evaluable».

- **Lugar**: favoritos, búsqueda por nombre, coordenadas a mano o GPS del teléfono.
- **Hora de vuelo**: botones para moverte de a una hora o un día; todo se recalcula para esa hora.
- **Actualización**: al abrir la app, cada 10 minutos mientras está a la vista, y con el botón *Actualizar*.

## Fuentes de datos y límites que conviene conocer

- **Clima y viento**: [Open-Meteo](https://open-meteo.com) (modelo numérico, resolución horaria). No son mediciones en el sitio. El modelo entrega viento a 10, 80, 120 y 180 m: los demás niveles se **interpolan** con la ley de potencia, y por encima de 180 m se **extrapolan** (marcado con `I` y `E` en la tabla). El nivel «suelo» es el de 10 m.
- **Densidad**: aire húmedo, con aire seco y vapor de agua calculados por separado. La temperatura y la presión a cada altura salen de los niveles del modelo y de la ecuación hidrostática; la humedad se supone con razón de mezcla constante.
- **Kp**: [NOAA SWPC](https://services.swpc.noaa.gov). Un Kp alto puede degradar el GNSS y la brújula.
- **Radar**: [RainViewer](https://www.rainviewer.com), gratuito para uso personal, solo las últimas 2 horas y zoom máximo 7. En el norte argentino la cobertura de radar es irregular: donde no hay radar cercano, el mapa no muestra lluvia aunque llueva. Activá *Mostrar dónde hay cobertura de radar* para verlo.
- **Luna**: cálculo astronómico propio, con error de 1–2° de elongación (unas 3 horas). Alcanza para decir qué fase es y cuánta iluminación tiene.
- **Mapa base**: © OpenStreetMap.

Esta app es una ayuda de planificación. No reemplaza las verificaciones previas al vuelo ni la normativa de la ANAC.

## Estructura

```
app/src/main/java/ar/densidad/aire/
  Physics.kt      densidad, perfil de viento y temperatura, luna
  Models.kt       datos y cálculo de condiciones a una hora
  Api.kt          Open-Meteo, NOAA y RainViewer
  AppViewModel.kt estado y actualización automática
  Screens.kt      Resumen, Viento, Pronóstico, Cielo
  MapScreen.kt    mapa y radar
  CompassScreen.kt brújula
  MainActivity.kt pantalla principal y selector de lugar
.github/workflows/build-apk.yml   compilación del APK
```
