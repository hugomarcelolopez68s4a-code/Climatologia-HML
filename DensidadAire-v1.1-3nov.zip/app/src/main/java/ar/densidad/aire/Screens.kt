package ar.densidad.aire

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant

// ================================================================= RESUMEN

@Composable
fun SummaryScreen(vm: AppViewModel, f: Forecast?, c: Conditions?) {
    val place = vm.place
    var elevText by remember(place.name, place.lat, place.lon) {
        mutableStateOf(place.elevOverride?.let { fmt(it, 0) } ?: "")
    }
    var aglText by remember { mutableStateOf(fmt(vm.aglM, 0)) }

    fun applyElevation() {
        if (elevText.isBlank()) vm.setElevation(null)
        else parseNum(elevText)?.let { vm.setElevation(it) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel {
            Text("Altura y altitud", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            val elevHint = when {
                place.elevOverride != null -> "Valor cargado a mano."
                f != null -> "Automática: " + fmt(f.elevationM, 0) + " m (modelo digital del terreno)."
                else -> "Vacío = automática."
            }
            NumField(
                "Altitud del sitio (m s.n.m.)", elevText, { elevText = it },
                hint = elevHint, onDone = { applyElevation() }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { applyElevation() }) { Text("Aplicar") }
                TextButton(onClick = { elevText = ""; vm.setElevation(null) }) { Text("Automática") }
            }
            NumField(
                "Altura de vuelo sobre el suelo (m)", aglText,
                { aglText = it; parseNum(it)?.let { v -> vm.updateAgl(v.coerceIn(0.0, 6000.0)) } },
                hint = "Se usa para la densidad y el viento. En montaña podés ir más allá de 120 m."
            )
        }

        if (c == null) {
            NoData(vm)
            return@Column
        }

        val z = vm.aglM
        val rho = c.atm.densityAt(z)
        val alt = c.siteElevM + z
        val isa = Phys.isaDensity(alt)
        val da = Phys.densityAltitudeM(rho)
        val tz = c.atm.tempAt(z)
        val pz = c.atm.pressureAt(z)
        val dry = pz * 100.0 / (Phys.RD * (tz + 273.15))
        val unit = vm.windUnit
        val wz = max(z, 10.0)
        val wSpeed = c.wind.speedAt(wz) * unit.factor
        val wDir = c.wind.dirAt(wz)

        Panel {
            Text("Densidad del aire", style = MaterialTheme.typography.labelLarge, color = muted)
            Text(
                fmt(rho, 3) + " kg/m³",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "a " + fmt(alt, 0) + " m s.n.m. (" + fmt(z, 0) + " m sobre el suelo)",
                color = muted
            )
            TileRow(
                "Respecto a ISA" to (signed((rho / isa - 1.0) * 100.0, 1) + " %"),
                "Respecto a nivel del mar" to (signed((rho / Phys.RHO0 - 1.0) * 100.0, 1) + " %")
            )
            TileRow(
                "Altitud densidad" to (fmt(da, 0) + " m"),
                "Altitud densidad" to (fmt(da * 3.28084, 0) + " ft")
            )
            Text(
                "Efecto de la humedad: " + signed((rho / dry - 1.0) * 100.0, 2) +
                    " % respecto al aire seco.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Panel {
            Text("Condiciones en el lugar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            TileRow(
                "Temperatura (2 m)" to (fmt(c.temp2, 1) + " °C"),
                "Humedad relativa" to (fmt(c.rh, 0) + " %")
            )
            TileRow(
                "Punto de rocío" to (fmt(c.dew, 1) + " °C"),
                "Presión en el sitio" to (fmt(c.pSite, 1) + " hPa")
            )
            TileRow(
                ("Viento a " + fmt(wz, 0) + " m") to (fmt(wSpeed, 1) + " " + unit.label),
                "Dirección (de donde sopla)" to (cardinal(wDir) + " " + fmt(wDir, 0) + "°")
            )
            TileRow(
                "Ráfagas (10 m)" to (fmt(c.gust10 * unit.factor, 1) + " " + unit.label),
                ("Temp. a " + fmt(z, 0) + " m") to (fmt(tz, 1) + " °C")
            )
            Text(
                "Datos de un modelo numérico (Open-Meteo), no son mediciones. Presión: " + c.pSource + ".",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

// ================================================================= VIENTO

@Composable
fun WindScreen(vm: AppViewModel, c: Conditions?) {
    var extraText by remember { mutableStateOf(vm.extraHeights) }
    val unit = vm.windUnit

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Unidad", color = muted)
            WindUnit.values().forEach { u -> Pill(u.label, unit == u) { vm.setUnit(u) } }
        }

        if (c == null) {
            NoData(vm)
            return@Column
        }

        val heights = (listOf(10.0, 20.0, 40.0, 60.0, 80.0, 100.0, 120.0, 180.0) + parseHeights(extraText))
            .distinct().sorted()

        Panel {
            Text("Viento por altura sobre el suelo", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            WindRow("Altura", "Fte.", "Viento", "Dirección", "Temp.", "ρ kg/m³", header = true)
            for (h in heights) {
                val src = when (c.wind.source(h)) {
                    Src.MODEL -> "M"
                    Src.INTERP -> "I"
                    Src.EXTRAP -> "E"
                }
                val d = c.wind.dirAt(h)
                WindRow(
                    (if (h == 10.0) "10 (suelo)" else fmt(h, 0)) + " m",
                    src,
                    fmt(c.wind.speedAt(h) * unit.factor, 1),
                    cardinal(d) + " " + fmt(d, 0) + "°",
                    fmt(c.atm.tempAt(h), 1),
                    fmt(c.atm.densityAt(h), 3)
                )
            }
            Text(
                "M = nivel que entrega el modelo (10, 80, 120 y 180 m). I = interpolado entre niveles. " +
                    "E = extrapolado fuera de 10–180 m, menos confiable. " +
                    "«Suelo» es el nivel más bajo del modelo (10 m); no hay dato a 2 m.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Panel {
            Text("Alturas extra", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = extraText,
                onValueChange = { extraText = it; vm.setExtra(it) },
                label = { Text("Metros sobre el suelo, separados por coma") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Ejemplo: 250, 400, 600. Sirve para montaña, donde 120 m no alcanza. " +
                    "Por encima de 180 m el valor se extrapola con la ley de potencia.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun WindRow(
    a: String, b: String, c: String, d: String, e: String, f: String,
    header: Boolean = false
) {
    val style = if (header) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodyMedium
    val color = if (header) muted else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(a, Modifier.weight(1.5f), style = style, color = color)
        Text(b, Modifier.weight(0.5f), style = style, color = color)
        Text(c, Modifier.weight(1.0f), style = style, color = color)
        Text(d, Modifier.weight(1.5f), style = style, color = color)
        Text(e, Modifier.weight(0.9f), style = style, color = color)
        Text(f, Modifier.weight(1.1f), style = style, color = color)
    }
}

// ================================================================= PRONÓSTICO

@Composable
fun ForecastScreen(vm: AppViewModel, f: Forecast?, epoch: Long) {
    if (f == null) {
        Column(Modifier.fillMaxSize().padding(16.dp)) { NoData(vm) }
        return
    }
    val unit = vm.windUnit
    val start = max(f.nearestIndex(epoch), 0)
    val end = min(f.time.size, start + 72)
    val rows = (start until end).toList()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(rows) { i ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        timeStr(f.time[i], f.zone, "EEE d · HH:mm"),
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        fmt(f.get("temperature_2m", i), 1) + " °C",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(wmoText(f.get("weather_code", i)), color = muted)
                Text(
                    "Lluvia " + fmt(f.get("precipitation_probability", i), 0) + " % · " +
                        fmt(f.get("precipitation", i), 1) + " mm · Nubes " +
                        fmt(f.get("cloud_cover", i), 0) + " %",
                    style = MaterialTheme.typography.bodySmall
                )
                val d10 = f.get("wind_direction_10m", i)
                val d120 = f.get("wind_direction_120m", i)
                Text(
                    "Viento 10 m: " + fmt(f.get("wind_speed_10m", i) * unit.factor, 0) + " " + unit.label +
                        " " + cardinal(d10) + " · ráfagas " + fmt(f.get("wind_gusts_10m", i) * unit.factor, 0),
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Viento 120 m: " + fmt(f.get("wind_speed_120m", i) * unit.factor, 0) + " " + unit.label +
                        " " + cardinal(d120) + " · humedad " + fmt(f.get("relative_humidity_2m", i), 0) + " %",
                    style = MaterialTheme.typography.bodySmall
                )
                val vis = f.get("visibility", i)
                val cape = f.get("cape", i)
                if (!vis.isNaN() || !cape.isNaN()) {
                    Text(
                        "Visibilidad " + fmt(vis / 1000.0, 0) + " km · CAPE " + fmt(cape, 0) + " J/kg",
                        style = MaterialTheme.typography.bodySmall,
                        color = muted
                    )
                }
            }
        }
    }
}

// ================================================================= CIELO (sol, luna, Kp)

private fun dayIndex(f: Forecast, epoch: Long): Int {
    val d = Instant.ofEpochSecond(epoch).atZone(f.zone).toLocalDate()
    for (i in f.sunrise.indices) {
        if (f.sunrise[i] > 0L && Instant.ofEpochSecond(f.sunrise[i]).atZone(f.zone).toLocalDate() == d) return i
    }
    return -1
}

@Composable
fun SkyScreen(vm: AppViewModel, f: Forecast?, epoch: Long, zone: ZoneId) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ---- sol
        Panel {
            Text("Sol", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            val di = if (f != null) dayIndex(f, epoch) else -1
            if (f != null && di >= 0 && di < f.sunset.size) {
                val sr = f.sunrise[di]
                val ss = f.sunset[di]
                TileRow(
                    "Amanecer" to timeStr(sr, f.zone, "HH:mm"),
                    "Atardecer" to timeStr(ss, f.zone, "HH:mm")
                )
                val hours = (ss - sr) / 3600.0
                Text(
                    "Luz diurna: " + fmt(hours, 1) + " h. A la hora elegida es de " +
                        (if (epoch in sr..ss) "día." else "noche."),
                    color = muted
                )
            } else {
                Text(if (vm.loading) "Cargando…" else "Sin datos de amanecer y atardecer para ese día.", color = muted)
            }
        }

        // ---- luna
        val psi = Moon.elongationDeg(epoch)
        val illum = Moon.illumination(psi)
        val nextFull = Moon.nextPhase(epoch, 180.0)
        val nextNew = Moon.nextPhase(epoch, 0.0)
        Panel {
            Text("Luna a la hora elegida", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                MoonIcon(psi, vm.place.lat < 0.0, Modifier.size(88.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(Moon.phaseName(psi), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Iluminación: " + fmt(illum * 100.0, 0) + " %")
                    Text("Próxima llena: " + timeStr(nextFull, zone, "EEE d MMM"), color = muted)
                    Text("Próxima nueva: " + timeStr(nextNew, zone, "EEE d MMM"), color = muted)
                }
            }
            Text(
                "Cálculo astronómico aproximado (±1 día en los bordes de cada fase). " +
                    "Se dibuja como se ve desde el hemisferio " + (if (vm.place.lat < 0.0) "sur." else "norte."),
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }

        // ---- Kp
        Panel {
            Text("Índice Kp (NOAA)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            val pts = vm.kp
            if (pts.isEmpty()) {
                Text(
                    if (vm.loading) "Cargando…" else (vm.kpError ?: "Sin datos de Kp."),
                    color = if (vm.kpError != null) MaterialTheme.colorScheme.error else muted
                )
            } else {
                val cur = pts.lastOrNull { it.epoch <= epoch }
                if (cur != null && epoch - cur.epoch <= 3L * 3600L + 60L) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            fmt(cur.kp, 1),
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold,
                            color = kpColor(cur.kp)
                        )
                        Column {
                            Text(kpLabel(cur.kp), fontWeight = FontWeight.SemiBold)
                            Text(
                                (if (cur.kind == "predicted") "Pronosticado" else "Observado") +
                                    " · intervalo de 3 h desde las " + timeStr(cur.epoch, zone, "HH:mm"),
                                color = muted,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                } else {
                    Text("NOAA no tiene Kp para la hora elegida (cubre unos 3 días).", color = muted)
                }

                val shown = pts.filter { it.epoch >= epoch - 6L * 3600L }.take(24)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(shown) { p ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(42.dp)) {
                            Text(fmt(p.kp, 1), style = MaterialTheme.typography.labelSmall)
                            Box(
                                Modifier
                                    .height((6.0 + 54.0 * (p.kp / 9.0)).dp)
                                    .width(24.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(kpColor(p.kp).copy(alpha = if (p.kind == "predicted") 0.55f else 1f))
                            )
                            Text(timeStr(p.epoch, zone, "HH"), style = MaterialTheme.typography.labelSmall, color = muted)
                            Text(timeStr(p.epoch, zone, "d/M"), style = MaterialTheme.typography.labelSmall, color = muted)
                        }
                    }
                }
                Text(
                    "Verde: calma (Kp menor a 4). Amarillo: activa. Naranja y rojo: tormenta geomagnética " +
                        "(escala G de NOAA, desde Kp 5). Las barras más claras son pronóstico. " +
                        "Una actividad alta puede afectar al GNSS y a la brújula.",
                    color = muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun MoonIcon(psiDeg: Double, southern: Boolean, modifier: Modifier = Modifier) {
    val dark = Color(0xFF2B3640)
    val lit = Color(0xFFF1E9C8)
    val waxing = psiDeg < 180.0
    val litOnRight = if (southern) !waxing else waxing
    val cosPsi = Math.cos(Math.toRadians(psiDeg)).toFloat()
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        val topLeft = Offset(c.x - r, c.y - r)
        val full = Size(2f * r, 2f * r)
        drawCircle(color = dark, radius = r, center = c)
        // mitad iluminada
        drawArc(
            color = lit,
            startAngle = if (litOnRight) -90f else 90f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = topLeft,
            size = full
        )
        // terminador (elipse): suma luz si es gibosa, la quita si es creciente/menguante
        val rx = abs(cosPsi) * r
        if (rx > 0.5f) {
            drawOval(
                color = if (cosPsi < 0f) lit else dark,
                topLeft = Offset(c.x - rx, c.y - r),
                size = Size(2f * rx, 2f * r)
            )
        }
    }
}
