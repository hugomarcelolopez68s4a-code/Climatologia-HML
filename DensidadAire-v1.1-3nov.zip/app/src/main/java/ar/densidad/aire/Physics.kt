package ar.densidad.aire

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

// ---------------------------------------------------------------- utilidades

val LOC: Locale = Locale.forLanguageTag("es-AR")

fun fmt(x: Double, dec: Int): String =
    if (x.isNaN() || x.isInfinite()) "—" else String.format(LOC, "%." + dec + "f", x)

fun signed(x: Double, dec: Int): String =
    if (x.isNaN()) "—" else (if (x > 0.0) "+" else "") + fmt(x, dec)

fun parseNum(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

fun timeStr(epoch: Long, zone: ZoneId, pattern: String): String =
    DateTimeFormatter.ofPattern(pattern, LOC).format(Instant.ofEpochSecond(epoch).atZone(zone))

fun nowSec(): Long = System.currentTimeMillis() / 1000

private val CARD = arrayOf(
    "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
    "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"
)

fun cardinal(deg: Double): String {
    if (deg.isNaN()) return "—"
    val norm = ((deg % 360.0) + 360.0) % 360.0
    return CARD[((norm / 22.5) + 0.5).toInt() % 16]
}

fun wmoText(code: Double): String {
    if (code.isNaN()) return "—"
    return when (code.toInt()) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        51, 53, 55 -> "Llovizna"
        56, 57 -> "Llovizna helada"
        61 -> "Lluvia débil"
        63 -> "Lluvia"
        65 -> "Lluvia fuerte"
        66, 67 -> "Lluvia helada"
        71, 73, 75 -> "Nieve"
        77 -> "Granizo fino"
        80 -> "Chubascos débiles"
        81 -> "Chubascos"
        82 -> "Chubascos fuertes"
        85, 86 -> "Chubascos de nieve"
        95 -> "Tormenta"
        96, 99 -> "Tormenta con granizo"
        else -> "—"
    }
}

enum class WindUnit(val label: String, val factor: Double) {
    KMH("km/h", 1.0),
    MS("m/s", 1.0 / 3.6),
    KT("nudos", 1.0 / 1.852)
}

// ---------------------------------------------------------------- física del aire

object Phys {
    const val RD = 287.058      // J/(kg·K) aire seco
    const val RV = 461.495      // J/(kg·K) vapor de agua
    const val G = 9.80665
    const val RHO0 = 1.225      // densidad ISA a nivel del mar
    const val LAPSE = 0.0065    // K/m

    /** Presión de saturación del vapor (hPa), fórmula de Buck sobre agua. */
    fun satVapHpa(tC: Double): Double =
        6.1121 * exp((18.678 - tC / 234.5) * (tC / (257.14 + tC)))

    fun dewPointC(tC: Double, rhPct: Double): Double {
        val b = 17.62
        val c = 243.12
        val gm = ln(max(rhPct, 0.1) / 100.0) + b * tC / (c + tC)
        return c * gm / (b - gm)
    }

    /** Densidad del aire húmedo (kg/m³): aire seco + vapor por separado. */
    fun density(pHpa: Double, tC: Double, eHpa: Double): Double {
        val tK = tC + 273.15
        return (pHpa - eHpa) * 100.0 / (RD * tK) + eHpa * 100.0 / (RV * tK)
    }

    fun isaPressureHpa(hM: Double): Double = 1013.25 * (1.0 - 2.25577e-5 * hM).pow(5.25588)
    fun isaTempC(hM: Double): Double = 15.0 - LAPSE * hM
    fun isaDensity(hM: Double): Double =
        isaPressureHpa(hM) * 100.0 / (RD * (isaTempC(hM) + 273.15))

    /** Altitud ISA a la que la densidad estándar iguala a [rho]. */
    fun densityAltitudeM(rho: Double): Double = 44330.8 * (1.0 - (rho / RHO0).pow(1.0 / 4.2559))

    /** Presión de estación a partir de la presión reducida a nivel del mar. */
    fun stationFromMsl(pMslHpa: Double, tSiteC: Double, hM: Double): Double {
        val tm = tSiteC + 273.15 + LAPSE * hM / 2.0
        return pMslHpa * exp(-G * hM / (RD * tm))
    }
}

/** Perfil vertical de temperatura, presión y vapor sobre el sitio (z = metros sobre el suelo). */
class AtmProfile(
    val pSiteHpa: Double,
    val e2Hpa: Double,
    t2: Double,
    t80: Double,
    t120: Double,
    t180: Double
) {
    private val pts: List<Pair<Double, Double>> = buildList {
        add(2.0 to t2)
        if (!t80.isNaN()) add(80.0 to t80)
        if (!t120.isNaN()) add(120.0 to t120)
        if (!t180.isNaN()) add(180.0 to t180)
    }

    fun tempAt(z: Double): Double {
        if (z <= pts.first().first) return pts.first().second
        for (i in 0 until pts.size - 1) {
            val za = pts[i].first
            val ta = pts[i].second
            val zb = pts[i + 1].first
            val tb = pts[i + 1].second
            if (z <= zb) return ta + (tb - ta) * (z - za) / (zb - za)
        }
        val zl = pts.last().first
        val tl = pts.last().second
        return tl - Phys.LAPSE * (z - zl)
    }

    fun pressureAt(z: Double): Double {
        if (z <= 0.0) return pSiteHpa
        val tm = (tempAt(0.0) + tempAt(z)) / 2.0 + 273.15
        return pSiteHpa * exp(-Phys.G * z / (Phys.RD * tm))
    }

    /** Se asume razón de mezcla constante: e proporcional a la presión. */
    fun vaporAt(z: Double): Double = e2Hpa * pressureAt(z) / pSiteHpa

    fun densityAt(z: Double): Double = Phys.density(pressureAt(z), tempAt(z), vaporAt(z))
}

enum class Src { MODEL, INTERP, EXTRAP }

/** Viento a distintas alturas a partir de los niveles del modelo (z, km/h, dirección de origen). */
class WindProfile(private val lv: List<Triple<Double, Double, Double>>) {

    private fun alpha(v1: Double, z1: Double, v2: Double, z2: Double): Double? =
        if (v1 > 0.5 && v2 > 0.5) ln(v2 / v1) / ln(z2 / z1) else null

    fun speedAt(z0: Double): Double {
        if (lv.isEmpty()) return Double.NaN
        val z = max(z0, 1.0)
        if (lv.size == 1) return lv[0].second * (z / lv[0].first).pow(0.14)
        if (z <= lv[0].first) {
            val a = (alpha(lv[0].second, lv[0].first, lv[1].second, lv[1].first) ?: 0.14)
                .coerceIn(0.0, 0.6)
            return lv[0].second * (z / lv[0].first).pow(a)
        }
        for (i in 0 until lv.size - 1) {
            val z1 = lv[i].first
            val v1 = lv[i].second
            val z2 = lv[i + 1].first
            val v2 = lv[i + 1].second
            if (z <= z2) {
                val a = alpha(v1, z1, v2, z2)
                return if (a != null) v1 * (z / z1).pow(a) else v1 + (v2 - v1) * (z - z1) / (z2 - z1)
            }
        }
        val zl = lv.last().first
        val vl = lv.last().second
        val zp = lv[lv.size - 2].first
        val vp = lv[lv.size - 2].second
        val a = (alpha(vp, zp, vl, zl) ?: 0.14).coerceIn(0.0, 0.5)
        return vl * (z / zl).pow(a)
    }

    fun dirAt(z0: Double): Double {
        if (lv.isEmpty()) return Double.NaN
        val z = max(z0, 1.0)
        if (z <= lv.first().first) return lv.first().third
        for (i in 0 until lv.size - 1) {
            val z1 = lv[i].first
            val z2 = lv[i + 1].first
            if (z <= z2) {
                val f = ln(z / z1) / ln(z2 / z1)
                val d1 = lv[i].third
                val d2 = lv[i + 1].third
                val diff = ((d2 - d1 + 540.0) % 360.0) - 180.0
                return (((d1 + diff * f) % 360.0) + 360.0) % 360.0
            }
        }
        return lv.last().third
    }

    fun source(z: Double): Src {
        if (lv.any { abs(it.first - z) < 0.5 }) return Src.MODEL
        if (lv.isEmpty()) return Src.EXTRAP
        return if (z > lv.last().first || z < lv.first().first) Src.EXTRAP else Src.INTERP
    }
}

// ---------------------------------------------------------------- Luna

object Moon {
    private fun rad(d: Double) = d * PI / 180.0

    /** Elongación Luna–Sol en grados: 0 = nueva, 180 = llena. Precisión de ~1–2°. */
    fun elongationDeg(epochSec: Long): Double {
        val d = epochSec / 86400.0 + 2440587.5 - 2451545.0
        val lm = 218.316 + 13.176396 * d + 6.289 * sin(rad(134.963 + 13.064993 * d))
        val g = rad(357.528 + 0.9856003 * d)
        val ls = 280.460 + 0.9856474 * d + 1.915 * sin(g) + 0.020 * sin(2.0 * g)
        return (((lm - ls) % 360.0) + 360.0) % 360.0
    }

    fun illumination(psiDeg: Double): Double = (1.0 - cos(rad(psiDeg))) / 2.0

    fun phaseName(psiDeg: Double): String = when {
        psiDeg < 22.5 || psiDeg >= 337.5 -> "Luna nueva"
        psiDeg < 67.5 -> "Creciente"
        psiDeg < 112.5 -> "Cuarto creciente"
        psiDeg < 157.5 -> "Gibosa creciente"
        psiDeg < 202.5 -> "Luna llena"
        psiDeg < 247.5 -> "Gibosa menguante"
        psiDeg < 292.5 -> "Cuarto menguante"
        else -> "Menguante"
    }

    private fun diff(psi: Double, target: Double): Double = ((psi - target + 540.0) % 360.0) - 180.0

    /** Próximo instante (epoch s, ±30 min) en que la elongación pasa por [targetDeg]. */
    fun nextPhase(fromEpoch: Long, targetDeg: Double): Long {
        var t = fromEpoch
        var prev = diff(elongationDeg(t), targetDeg)
        val limit = fromEpoch + 32L * 86400L
        while (t < limit) {
            t += 1800L
            val cur = diff(elongationDeg(t), targetDeg)
            if (prev < 0.0 && cur >= 0.0) return t
            prev = cur
        }
        return limit
    }
}
