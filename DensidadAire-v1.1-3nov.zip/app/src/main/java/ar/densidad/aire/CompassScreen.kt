package ar.densidad.aire

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CompassScreen(lat: Double, lon: Double, altM: Double, windFrom: Double?) {
    val ctx = LocalContext.current
    var azimuth by remember { mutableFloatStateOf(0f) }
    var available by remember { mutableStateOf(true) }
    var accuracy by remember { mutableIntStateOf(SensorManager.SENSOR_STATUS_UNRELIABLE) }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            available = false
            onDispose { }
        } else {
            val rot = FloatArray(9)
            val rot2 = FloatArray(9)
            val ori = FloatArray(3)
            var smooth = Double.NaN
            val listener = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    SensorManager.getOrientation(rot, ori)
                    var az = ori[0].toDouble()
                    // Teléfono parado (vertical): se toma la dirección de la cámara trasera.
                    if (abs(ori[1].toDouble()) > 0.8) {
                        SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, rot2)
                        SensorManager.getOrientation(rot2, ori)
                        az = ori[0].toDouble()
                    }
                    val deg = (Math.toDegrees(az) + 360.0) % 360.0
                    smooth = if (smooth.isNaN()) {
                        deg
                    } else {
                        val diff = ((deg - smooth + 540.0) % 360.0) - 180.0
                        ((smooth + 0.2 * diff) + 360.0) % 360.0
                    }
                    azimuth = smooth.toFloat()
                }

                override fun onAccuracyChanged(s: Sensor?, a: Int) {
                    accuracy = a
                }
            }
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(listener) }
        }
    }

    val declination = remember(lat, lon, altM) {
        GeomagneticField(lat.toFloat(), lon.toFloat(), altM.toFloat(), System.currentTimeMillis()).declination
    }
    val magnetic = azimuth.toDouble()
    val trueHeading = (magnetic + declination + 360.0) % 360.0

    val cs = MaterialTheme.colorScheme
    val bg = cs.surfaceVariant
    val fg = cs.onSurface
    val outline = cs.outline
    val north = Color(0xFFD13B3B)
    val pointer = cs.primary
    val windColor = Color(0xFF2E86DE)
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!available) {
            Panel {
                Text("Este teléfono no tiene sensor de brújula.", color = cs.error)
            }
            return@Column
        }

        Canvas(Modifier.size(300.dp)) {
            val r = size.minDimension / 2f
            val c = center
            drawCircle(color = bg, radius = r, center = c)
            drawCircle(color = outline, radius = r, center = c, style = Stroke(width = 3f))

            rotate(degrees = -trueHeading.toFloat(), pivot = c) {
                for (a in 0 until 360 step 10) {
                    val major = a % 90 == 0
                    val len = if (major) 26f else if (a % 30 == 0) 18f else 10f
                    val ang = Math.toRadians(a.toDouble())
                    val sx = c.x + (r - 4f) * sin(ang).toFloat()
                    val sy = c.y - (r - 4f) * cos(ang).toFloat()
                    val ex = c.x + (r - 4f - len) * sin(ang).toFloat()
                    val ey = c.y - (r - 4f - len) * cos(ang).toFloat()
                    drawLine(
                        color = if (a == 0) north else fg,
                        start = Offset(sx, sy),
                        end = Offset(ex, ey),
                        strokeWidth = if (major) 5f else 2f
                    )
                }
                drawIntoCanvas { cv ->
                    paint.textSize = 22.sp.toPx()
                    val labels = listOf("N" to 0, "E" to 90, "S" to 180, "O" to 270)
                    for ((t, a) in labels) {
                        val ang = Math.toRadians(a.toDouble())
                        val rr = r - 56f
                        val x = c.x + rr * sin(ang).toFloat()
                        val y = c.y - rr * cos(ang).toFloat() + paint.textSize * 0.35f
                        paint.color = (if (a == 0) north else fg).toArgb()
                        cv.nativeCanvas.drawText(t, x, y, paint)
                    }
                    if (windFrom != null) {
                        val ang = Math.toRadians(windFrom)
                        val rr = r - 40f
                        val x = c.x + rr * sin(ang).toFloat()
                        val y = c.y - rr * cos(ang).toFloat()
                        paint.color = windColor.toArgb()
                        cv.nativeCanvas.drawCircle(x, y, 14f, paint)
                        paint.color = Color.White.toArgb()
                        paint.textSize = 16.sp.toPx()
                        cv.nativeCanvas.drawText("V", x, y + paint.textSize * 0.35f, paint)
                    }
                }
            }

            // puntero fijo: hacia donde apunta el teléfono
            val tri = Path().apply {
                moveTo(c.x, c.y - r + 4f)
                lineTo(c.x - 13f, c.y - r + 34f)
                lineTo(c.x + 13f, c.y - r + 34f)
                close()
            }
            drawPath(tri, color = pointer)
            drawCircle(color = pointer, radius = 6f, center = c)
        }

        Panel {
            Text(
                fmt(trueHeading, 0) + "° " + cardinal(trueHeading),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = cs.primary
            )
            Text("Rumbo verdadero (respecto del norte geográfico)", color = cs.onSurfaceVariant)
            Tile("Rumbo magnético", fmt(magnetic, 0) + "°")
            Tile(
                "Declinación magnética",
                signed(declination.toDouble(), 1) + "° (" + (if (declination < 0f) "oeste" else "este") + ")"
            )
            if (windFrom != null) {
                Tile("Viento (círculo V)", "desde " + cardinal(windFrom) + " " + fmt(windFrom, 0) + "°")
            }
            if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) {
                Text(
                    "La brújula necesita calibración: mové el teléfono dibujando un 8 en el aire.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                "Con el teléfono plano apunta la parte de arriba; parado, la cámara trasera. " +
                    "Alejalo de metales e imanes. No reemplaza la calibración de la brújula de tu equipo de vuelo.",
                color = cs.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
