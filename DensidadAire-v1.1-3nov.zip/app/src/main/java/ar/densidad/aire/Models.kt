package ar.densidad.aire

import java.time.ZoneId
import kotlin.math.abs

data class Place(
    val name: String,
    val lat: Double,
    val lon: Double,
    val elevOverride: Double? = null
)

data class GeoResult(val label: String, val lat: Double, val lon: Double)

data class KpPoint(val epoch: Long, val kp: Double, val kind: String)

data class RadarFrame(val time: Long, val path: String)

data class RadarFrames(val host: String, val frames: List<RadarFrame>)

class Forecast(
    val elevationM: Double,
    val zone: ZoneId,
    val time: LongArray,
    private val series: Map<String, DoubleArray>,
    val sunrise: LongArray,
    val sunset: LongArray
) {
    fun get(name: String, i: Int): Double = series[name]?.getOrNull(i) ?: Double.NaN

    fun nearestIndex(epoch: Long): Int {
        if (time.isEmpty()) return -1
        var best = 0
        var bestD = Long.MAX_VALUE
        for (i in time.indices) {
            val d = abs(time[i] - epoch)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }
}

/** Condiciones calculadas para un instante y un sitio. */
class Conditions(
    val epoch: Long,
    val siteElevM: Double,
    val temp2: Double,
    val rh: Double,
    val dew: Double,
    val pSite: Double,
    val pSource: String,
    val atm: AtmProfile,
    val wind: WindProfile,
    val gust10: Double
)

fun buildConditions(f: Forecast, epoch: Long, elevOverride: Double?): Conditions? {
    val i = f.nearestIndex(epoch)
    if (i < 0) return null
    val t2 = f.get("temperature_2m", i)
    val rh = f.get("relative_humidity_2m", i)
    if (t2.isNaN() || rh.isNaN()) return null

    val dewApi = f.get("dew_point_2m", i)
    val dew = if (dewApi.isNaN()) Phys.dewPointC(t2, rh) else dewApi
    val site = elevOverride ?: f.elevationM

    // Presión de estación: se usa la del modelo si coincide con la derivada de la
    // presión a nivel del mar; si no coinciden se prefiere la derivada.
    val ps = f.get("surface_pressure", i)
    val pm = f.get("pressure_msl", i)
    val pDerived = if (pm.isNaN()) Double.NaN else Phys.stationFromMsl(pm, t2, site)
    val pSite: Double
    val src: String
    if (!ps.isNaN() && (pDerived.isNaN() || abs(ps - pDerived) <= 5.0)) {
        pSite = ps
        src = "presión en superficie del modelo"
    } else if (!pDerived.isNaN()) {
        pSite = pDerived
        src = "reducida desde presión a nivel del mar"
    } else {
        pSite = Phys.isaPressureHpa(site)
        src = "atmósfera estándar (sin dato del modelo)"
    }

    val e2 = Phys.satVapHpa(dew)
    val atm = AtmProfile(
        pSite, e2, t2,
        f.get("temperature_80m", i), f.get("temperature_120m", i), f.get("temperature_180m", i)
    )

    val levels = ArrayList<Triple<Double, Double, Double>>()
    for ((z, suffix) in listOf(10.0 to "10m", 80.0 to "80m", 120.0 to "120m", 180.0 to "180m")) {
        val v = f.get("wind_speed_$suffix", i)
        val d = f.get("wind_direction_$suffix", i)
        if (!v.isNaN() && !d.isNaN()) levels.add(Triple(z, v, d))
    }

    return Conditions(
        epoch, site, t2, rh, dew, pSite, src, atm, WindProfile(levels), f.get("wind_gusts_10m", i)
    )
}
