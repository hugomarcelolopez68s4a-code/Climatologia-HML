package ar.densidad.aire

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.ZoneId

@Composable
fun PhotosScreen(vm: AppViewModel, f: Forecast?, now: Long, zone: ZoneId) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<File?>(null) }
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val p = pending
        if (p != null) {
            if (ok) vm.photoTaken(p) else p.delete()
        }
        pending = null
    }
    val chosen = vm.photos.filter { it.name in vm.selectedPhotos }.take(4)
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel {
            Text("Fotos del lugar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Button(onClick = {
                val file = vm.newPhotoFile()
                pending = file
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
                takePicture.launch(uri)
            }) { Text("Sacar foto") }
            Text(
                "Podés sacar varias. Tocá una foto para sumarla o quitarla de la comparación " +
                    "(se usan hasta 4, las más recientes).",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (vm.photos.isEmpty()) {
            Panel { Text("Todavía no hay fotos.", color = muted) }
        } else {
            Panel {
                vm.photos.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { file -> PhotoCell(vm, file, zone, Modifier.weight(1f)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }

        Panel {
            Text(
                "Comparar con los datos del pronóstico",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            val newest = if (chosen.isEmpty()) 0L else chosen.maxOf { it.lastModified() } / 1000L
            val running = vm.analysis == AnalysisState.Running
            val canRun = chosen.isNotEmpty() && f != null && vm.activeKey.isNotBlank() && !running

            Button(
                enabled = canRun,
                onClick = {
                    if (f != null) vm.analyze(chosen, dataTextFor(f, newest, vm.place))
                }
            ) { Text("Analizar " + chosen.size + (if (chosen.size == 1) " foto" else " fotos")) }

            if (vm.activeKey.isBlank()) {
                Text("Falta la clave de " + vm.provider.label + ": cargala en Ajustes.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (f == null) {
                Text("Esperando los datos del pronóstico.", color = muted, style = MaterialTheme.typography.bodySmall)
            }
            if (chosen.isEmpty()) {
                Text("Elegí al menos una foto.", color = muted, style = MaterialTheme.typography.bodySmall)
            }
            if (chosen.isNotEmpty() && now - newest > 3L * 3600L) {
                Text(
                    "La foto es de hace más de 3 horas: se compara con el pronóstico de la hora en que se sacó.",
                    color = muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            when (val a = vm.analysis) {
                is AnalysisState.Idle -> {}
                is AnalysisState.Running -> {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Text("Analizando las fotos…")
                    }
                }
                is AnalysisState.Failed -> Text(a.message, color = MaterialTheme.colorScheme.error)
                is AnalysisState.Done -> ResultView(a.result)
            }

            Text(
                "Las fotos elegidas se envían a " + vm.provider.label + " para interpretarlas. " +
                    (if (vm.provider == AiProvider.GEMINI)
                        "En el nivel gratuito de Gemini, Google puede usar lo que enviás para mejorar sus productos. "
                    else "El uso de la API de Claude se cobra aparte. ") +
                    "La interpretación es automática y puede equivocarse: una foto no mide temperatura ni presión.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun PhotoCell(vm: AppViewModel, file: File, zone: ZoneId, modifier: Modifier) {
    val selected = file.name in vm.selectedPhotos
    val bmp by produceState<ImageBitmap?>(null, file.path) {
        value = withContext(Dispatchers.IO) { Img.decode(file, 360)?.asImageBitmap() }
    }
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(10.dp)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(shape)
                .background(cs.surfaceVariant)
                .border(if (selected) 3.dp else 0.dp, cs.primary, shape)
                .clickable { vm.toggleSelected(file) }
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    bitmap = b,
                    contentDescription = "Foto del lugar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (selected) {
                Text(
                    "✓",
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(cs.primary)
                        .padding(horizontal = 7.dp, vertical = 1.dp),
                    color = cs.onPrimary,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
        Text(
            timeStr(file.lastModified() / 1000L, zone, "d/M HH:mm"),
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant
        )
        TextButton(onClick = { vm.deletePhoto(file) }, contentPadding = PaddingValues(0.dp)) {
            Text("Borrar", style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun matchColor(m: String): Color = when (m) {
    "si" -> GoodGreen
    "parcial" -> WarnYellow
    "no" -> BadRed
    else -> Color(0xFF7C8B99)
}

private fun matchMark(m: String): String = when (m) {
    "si" -> "✓"
    "parcial" -> "≈"
    "no" -> "✕"
    else -> "?"
}

@Composable
private fun ResultView(r: AiResult) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val verdict: Pair<String, Color>? = when (r.verdict) {
        "coincide" -> "Coincide" to GoodGreen
        "coincide_en_parte" -> "Coincide en parte" to WarnYellow
        "no_coincide" -> "No coincide" to BadRed
        "no_evaluable" -> "No evaluable" to Color(0xFF7C8B99)
        else -> null
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (verdict != null) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(verdict.second)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(verdict.first, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        if (r.summary.isNotBlank()) Text(r.summary)
        for (p in r.points) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    matchMark(p.match),
                    color = matchColor(p.match),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Column(Modifier.weight(1f)) {
                    Text(p.topic, fontWeight = FontWeight.SemiBold)
                    if (p.photo.isNotBlank()) Text("En la foto: " + p.photo, style = MaterialTheme.typography.bodySmall)
                    if (p.data.isNotBlank()) Text("Datos: " + p.data, style = MaterialTheme.typography.bodySmall, color = muted)
                }
            }
        }
    }
}
