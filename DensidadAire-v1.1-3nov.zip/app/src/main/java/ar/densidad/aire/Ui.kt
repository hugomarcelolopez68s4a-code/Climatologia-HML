package ar.densidad.aire

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

val GoodGreen = Color(0xFF2E9E5B)
val WarnYellow = Color(0xFFD9A400)
val WarnOrange = Color(0xFFE0701A)
val BadRed = Color(0xFFD13B3B)

enum class ThemeMode(val label: String) {
    AUTO("Automático"),
    LIGHT("Claro"),
    DARK("Oscuro")
}

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFF90CAF9), onPrimary = Color(0xFF0B2A4A),
            secondary = Color(0xFF4FC3F7), onSecondary = Color(0xFF00283A),
            background = Color(0xFF0A1626), onBackground = Color(0xFFE3EDF8),
            surface = Color(0xFF112238), onSurface = Color(0xFFE3EDF8),
            surfaceVariant = Color(0xFF1B3350), onSurfaceVariant = Color(0xFFA9BDD3),
            outline = Color(0xFF5B7794), error = Color(0xFFFF8A80)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF1565C0), onPrimary = Color(0xFFFFFFFF),
            secondary = Color(0xFF0277BD), onSecondary = Color(0xFFFFFFFF),
            background = Color(0xFFEAF2FB), onBackground = Color(0xFF0E1F33),
            surface = Color(0xFFFFFFFF), onSurface = Color(0xFF0E1F33),
            surfaceVariant = Color(0xFFD9E7F7), onSurfaceVariant = Color(0xFF3B536B),
            outline = Color(0xFF7C93AD), error = Color(0xFFB3261E)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Tile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TileRow(first: Pair<String, String>, second: Pair<String, String>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile(first.first, first.second, Modifier.weight(1f))
        Tile(second.first, second.second, Modifier.weight(1f))
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            color = if (selected) cs.onPrimary else cs.onSurfaceVariant,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
fun NumField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    hint: String? = null,
    onDone: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        supportingText = if (hint != null) ({ Text(hint) }) else null,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun NoData(vm: AppViewModel) {
    Panel {
        if (vm.loading) {
            Text("Cargando datos del lugar…")
        } else {
            Text(
                vm.forecastError ?: "Todavía no hay datos.",
                color = MaterialTheme.colorScheme.error
            )
            Button(onClick = { vm.refresh() }) { Text("Reintentar") }
        }
    }
}

fun kpColor(kp: Double): Color = when {
    kp < 4.0 -> GoodGreen
    kp < 5.0 -> WarnYellow
    kp < 6.0 -> WarnOrange
    else -> BadRed
}

fun kpLabel(kp: Double): String = when {
    kp < 4.0 -> "Calma"
    kp < 5.0 -> "Activa"
    kp < 6.0 -> "Tormenta G1"
    kp < 7.0 -> "Tormenta G2"
    kp < 8.0 -> "Tormenta G3"
    kp < 9.0 -> "Tormenta G4"
    else -> "Tormenta G5"
}
