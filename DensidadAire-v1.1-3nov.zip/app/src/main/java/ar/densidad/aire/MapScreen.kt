package ar.densidad.aire

import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.roundToInt

fun initOsm(ctx: Context) {
    val cfg = Configuration.getInstance()
    cfg.load(ctx, ctx.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
    cfg.userAgentValue = ctx.packageName
    cfg.osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
    cfg.osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
}

/** Fuente de teselas de RainViewer. El nivel de zoom máximo del servicio gratuito es 7. */
class RainTileSource(
    name: String,
    private val host: String,
    private val pathFor: (Int, Int, Int) -> String
) : OnlineTileSourceBase(name, 0, 7, 256, ".png", arrayOf(host)) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return host + pathFor(z, x, y)
    }
}

class RadarLayers(private val ctx: Context, private val map: MapView) {
    private val frames = ArrayList<TilesOverlay>()
    private var coverageOverlay: TilesOverlay? = null
    private var marker: Marker? = null
    private val added = ArrayList<Overlay>()
    private var current = -1

    private fun overlay(src: OnlineTileSourceBase, alpha: Float): TilesOverlay {
        val provider = MapTileProviderBasic(ctx, src)
        val o = TilesOverlay(provider, ctx)
        o.loadingBackgroundColor = android.graphics.Color.TRANSPARENT
        o.loadingLineColor = android.graphics.Color.TRANSPARENT
        val cm = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1f, 0f, 0f,
                0f, 0f, 0f, alpha, 0f
            )
        )
        o.setColorFilter(ColorMatrixColorFilter(cm))
        return o
    }

    private fun relayer() {
        map.overlays.removeAll(added)
        added.clear()
        coverageOverlay?.let { added.add(it) }
        added.addAll(frames)
        marker?.let { added.add(it) }
        map.overlays.addAll(added)
        show(current)
    }

    fun setPlace(p: Place) {
        val m = Marker(map)
        m.position = GeoPoint(p.lat, p.lon)
        m.title = p.name
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        m.setInfoWindow(null)
        marker = m
        relayer()
    }

    fun setFrames(radar: RadarFrames?) {
        val old = ArrayList(frames)
        map.overlays.removeAll(old)
        old.forEach { it.onDetach(map) }
        frames.clear()
        if (radar != null) {
            for (fr in radar.frames) {
                val path = fr.path
                val src = RainTileSource("rv_" + fr.time, radar.host) { z, x, y ->
                    path + "/256/" + z + "/" + x + "/" + y + "/2/1_0.png"
                }
                frames.add(overlay(src, 0.75f))
            }
        }
        current = -1
        relayer()
    }

    fun setCoverage(host: String?, on: Boolean) {
        val old = coverageOverlay
        if (old != null) {
            map.overlays.removeAll(listOf(old))
            old.onDetach(map)
        }
        coverageOverlay = if (on && host != null) {
            overlay(
                RainTileSource("rv_coverage", host) { z, x, y ->
                    "/v2/coverage/0/256/" + z + "/" + x + "/" + y + "/0/0_0.png"
                },
                0.5f
            )
        } else null
        relayer()
    }

    fun show(index: Int) {
        current = index
        frames.forEachIndexed { i, o -> o.isEnabled = (i == index) }
        map.invalidate()
    }

    fun clear() {
        map.overlays.removeAll(added)
        frames.forEach { it.onDetach(map) }
        coverageOverlay?.onDetach(map)
        frames.clear()
        added.clear()
        coverageOverlay = null
        marker = null
    }
}

@Composable
fun MapScreen(vm: AppViewModel, zone: ZoneId, now: Long) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val radar = vm.radar
    val place = vm.place
    var frame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(true) }
    var coverage by remember { mutableStateOf(false) }

    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            minZoomLevel = 4.0
            maxZoomLevel = 7.0
            controller.setZoom(6.0)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        }
    }
    val layers = remember { RadarLayers(ctx, mapView) }

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) mapView.onResume()
            else if (e == Lifecycle.Event.ON_PAUSE) mapView.onPause()
        }
        owner.lifecycle.addObserver(obs)
        mapView.onResume()
        onDispose {
            owner.lifecycle.removeObserver(obs)
            layers.clear()
            mapView.onDetach()
        }
    }

    LaunchedEffect(place.name, place.lat, place.lon) {
        layers.setPlace(place)
        mapView.controller.setCenter(GeoPoint(place.lat, place.lon))
    }
    LaunchedEffect(radar) {
        layers.setFrames(radar)
        if (radar != null && radar.frames.isNotEmpty()) frame = radar.frames.size - 1
    }
    LaunchedEffect(frame, radar) {
        val n = radar?.frames?.size ?: 0
        layers.show(if (n == 0) -1 else frame.coerceIn(0, n - 1))
    }
    LaunchedEffect(coverage, radar) {
        layers.setCoverage(radar?.host, coverage)
    }
    LaunchedEffect(playing, radar) {
        val n = radar?.frames?.size ?: 0
        while (playing && n > 1) {
            delay(if (frame >= n - 1) 1600L else 600L)
            frame = (frame + 1) % n
        }
    }

    Column(Modifier.fillMaxSize()) {
        AndroidView(factory = { mapView }, modifier = Modifier.fillMaxWidth().weight(1f))

        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (radar == null || radar.frames.isEmpty()) {
                Text(
                    vm.radarError ?: "Cargando radar…",
                    color = if (vm.radarError != null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val n = radar.frames.size
                val fr = radar.frames[frame.coerceIn(0, n - 1)]
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill(if (playing) "Pausa" else "Reproducir", true) { playing = !playing }
                    Text(
                        timeStr(fr.time, zone, "EEE HH:mm") + " · hace " + max(0L, (now - fr.time) / 60L) + " min",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                if (n > 1) {
                    Slider(
                        value = frame.coerceIn(0, n - 1).toFloat(),
                        onValueChange = { playing = false; frame = it.roundToInt() },
                        valueRange = 0f..(n - 1).toFloat(),
                        steps = max(n - 2, 0)
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Switch(checked = coverage, onCheckedChange = { coverage = it })
                Text("Mostrar dónde hay cobertura de radar", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Radar de lluvia: RainViewer, últimas 2 horas, zoom máximo 7. " +
                    "Donde no hay radar cercano no se ve nada. Mapa: © OpenStreetMap.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
