package ar.densidad.aire

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("densidad_aire", Context.MODE_PRIVATE)

    fun loadPlaces(): List<Place> {
        val s = sp.getString("places", null)
        if (s != null) {
            try {
                val a = JSONArray(s)
                val out = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    Place(
                        o.getString("name"),
                        o.getDouble("lat"),
                        o.getDouble("lon"),
                        if (o.isNull("elev")) null else o.getDouble("elev")
                    )
                }
                if (out.isNotEmpty()) return out
            } catch (e: Exception) {
                // se usan los lugares por defecto
            }
        }
        return DEFAULT_PLACES
    }

    fun savePlaces(list: List<Place>) {
        val a = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("name", p.name)
            o.put("lat", p.lat)
            o.put("lon", p.lon)
            o.put("elev", p.elevOverride ?: JSONObject.NULL)
            a.put(o)
        }
        sp.edit().putString("places", a.toString()).apply()
    }

    fun loadSelected(): Int = sp.getInt("selected", 0)
    fun saveSelected(i: Int) = sp.edit().putInt("selected", i).apply()

    fun loadAgl(): Double = sp.getFloat("agl", 0f).toDouble()
    fun saveAgl(v: Double) = sp.edit().putFloat("agl", v.toFloat()).apply()

    fun loadUnit(): WindUnit =
        try {
            WindUnit.valueOf(sp.getString("unit", "KMH") ?: "KMH")
        } catch (e: Exception) {
            WindUnit.KMH
        }

    fun saveUnit(u: WindUnit) = sp.edit().putString("unit", u.name).apply()

    fun loadExtra(): String = sp.getString("extra", "") ?: ""
    fun saveExtra(s: String) = sp.edit().putString("extra", s).apply()

    fun loadTheme(): ThemeMode =
        try {
            ThemeMode.valueOf(sp.getString("theme", "AUTO") ?: "AUTO")
        } catch (e: Exception) {
            ThemeMode.AUTO
        }

    fun saveTheme(m: ThemeMode) = sp.edit().putString("theme", m.name).apply()

    fun loadKey(): String = sp.getString("ai_key", "") ?: ""
    fun loadModel(): String = sp.getString("ai_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun saveAi(key: String, model: String) =
        sp.edit().putString("ai_key", key).putString("ai_model", model).apply()

    fun loadProvider(): AiProvider =
        try {
            AiProvider.valueOf(sp.getString("ai_provider", "GEMINI") ?: "GEMINI")
        } catch (e: Exception) {
            AiProvider.GEMINI
        }

    fun saveProvider(p: AiProvider) = sp.edit().putString("ai_provider", p.name).apply()

    fun loadGeminiKey(): String = sp.getString("gemini_key", "") ?: ""
    fun loadGeminiModel(): String = sp.getString("gemini_model", DEFAULT_GEMINI) ?: DEFAULT_GEMINI
    fun saveGemini(key: String, model: String) =
        sp.edit().putString("gemini_key", key).putString("gemini_model", model).apply()

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        const val DEFAULT_GEMINI = "gemini-3.8-flash"

        val DEFAULT_PLACES = listOf(
            Place("Formosa (Formosa)", -26.1775, -58.1781),
            Place("San Salvador de Jujuy (Jujuy)", -24.1858, -65.2995)
        )
    }
}
