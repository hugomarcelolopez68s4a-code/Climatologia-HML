package ar.densidad.aire

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.Locale

class HttpException(val code: Int, message: String) : IOException(message)

object Api {

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "DensidadAire/1.0 (Android)")
        c.setRequestProperty("Accept", "application/json")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpException(code, "HTTP $code: " + body.take(160))
            return body
        } finally {
            c.disconnect()
        }
    }

    private fun JSONArray.doubles(): DoubleArray =
        DoubleArray(length()) { if (isNull(it)) Double.NaN else getDouble(it) }

    private fun JSONArray.longs(): LongArray =
        LongArray(length()) { if (isNull(it)) 0L else getLong(it) }

    // ------------------------------------------------------------ Open-Meteo

    private val HOURLY_FULL = listOf(
        "temperature_2m", "apparent_temperature", "relative_humidity_2m", "dew_point_2m",
        "surface_pressure", "pressure_msl",
        "precipitation_probability", "precipitation", "weather_code", "cloud_cover",
        "visibility", "cape",
        "wind_speed_10m", "wind_speed_80m", "wind_speed_120m", "wind_speed_180m",
        "wind_direction_10m", "wind_direction_80m", "wind_direction_120m", "wind_direction_180m",
        "wind_gusts_10m",
        "temperature_80m", "temperature_120m", "temperature_180m"
    )

    // Lista reducida por si el servicio rechazara alguna variable de la lista completa.
    private val HOURLY_SAFE = listOf(
        "temperature_2m", "apparent_temperature", "relative_humidity_2m", "dew_point_2m",
        "surface_pressure", "pressure_msl",
        "precipitation_probability", "precipitation", "weather_code", "cloud_cover",
        "wind_speed_10m", "wind_speed_80m", "wind_speed_120m", "wind_speed_180m",
        "wind_direction_10m", "wind_direction_80m", "wind_direction_120m", "wind_direction_180m",
        "wind_gusts_10m"
    )

    fun forecast(lat: Double, lon: Double, elev: Double?): Forecast {
        return try {
            forecastWith(lat, lon, elev, HOURLY_FULL)
        } catch (e: HttpException) {
            if (e.code == 400) forecastWith(lat, lon, elev, HOURLY_SAFE) else throw e
        }
    }

    private fun forecastWith(lat: Double, lon: Double, elev: Double?, vars: List<String>): Forecast {
        val q = StringBuilder("https://api.open-meteo.com/v1/forecast")
        q.append("?latitude=").append(String.format(Locale.US, "%.4f", lat))
        q.append("&longitude=").append(String.format(Locale.US, "%.4f", lon))
        q.append("&hourly=").append(vars.joinToString(","))
        q.append("&daily=sunrise,sunset")
        q.append("&timezone=auto&timeformat=unixtime&wind_speed_unit=kmh")
        q.append("&past_days=1&forecast_days=7")
        if (elev != null) q.append("&elevation=").append(String.format(Locale.US, "%.0f", elev))

        val root = JSONObject(http(q.toString()))
        val zone = try {
            ZoneId.of(root.optString("timezone", "UTC"))
        } catch (e: Exception) {
            ZoneOffset.UTC
        }
        val elevation = root.optDouble("elevation", Double.NaN)
        val h = root.getJSONObject("hourly")
        val time = h.getJSONArray("time").longs()
        val series = HashMap<String, DoubleArray>()
        for (v in vars) {
            val a = h.optJSONArray(v)
            if (a != null) series[v] = a.doubles()
        }
        val d = root.optJSONObject("daily")
        val sunrise = d?.optJSONArray("sunrise")?.longs() ?: LongArray(0)
        val sunset = d?.optJSONArray("sunset")?.longs() ?: LongArray(0)
        return Forecast(elevation, zone, time, series, sunrise, sunset)
    }

    fun geocode(name: String): List<GeoResult> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(name.trim(), "UTF-8") + "&count=6&language=es&format=json"
        val root = JSONObject(http(url))
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<GeoResult>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val parts = listOf(o.optString("name"), o.optString("admin1"), o.optString("country"))
                .filter { it.isNotBlank() }
            out.add(GeoResult(parts.joinToString(", "), o.getDouble("latitude"), o.getDouble("longitude")))
        }
        return out
    }

    // ------------------------------------------------------------ NOAA SWPC (Kp)

    fun kp(): List<KpPoint> {
        val urls = listOf(
            "https://services.swpc.noaa.gov/products/noaa-planetary-k-index-forecast.json",
            "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json"
        )
        var last: Exception? = null
        for (u in urls) {
            try {
                val pts = parseKp(http(u))
                if (pts.isNotEmpty()) return pts
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Sin datos de Kp")
    }

    private fun parseNoaaTime(s: String): Long? {
        val t = s.trim().replace(' ', 'T')
        return try {
            if (t.endsWith("Z")) Instant.parse(t).epochSecond
            else LocalDateTime.parse(t).toEpochSecond(ZoneOffset.UTC)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseKp(body: String): List<KpPoint> {
        val arr = JSONArray(body)
        val out = ArrayList<KpPoint>()
        if (arr.length() == 0) return out
        val first = arr.get(0)
        if (first is JSONArray) {
            val header = (0 until first.length()).map { first.optString(it).lowercase() }
            val iT = header.indexOf("time_tag")
            val iK = header.indexOfFirst { it == "kp" || it == "kp_index" }
            val iO = header.indexOf("observed")
            if (iT < 0 || iK < 0) return out
            for (r in 1 until arr.length()) {
                val row = arr.optJSONArray(r) ?: continue
                val t = parseNoaaTime(row.optString(iT)) ?: continue
                val k = row.opt(iK)?.toString()?.toDoubleOrNull() ?: continue
                val kind = if (iO >= 0) row.optString(iO) else "observed"
                out.add(KpPoint(t, k, kind))
            }
        } else {
            for (r in 0 until arr.length()) {
                val o = arr.optJSONObject(r) ?: continue
                val t = parseNoaaTime(o.optString("time_tag")) ?: continue
                val raw = o.opt("kp") ?: o.opt("Kp") ?: o.opt("kp_index")
                val k = raw?.toString()?.toDoubleOrNull() ?: continue
                val kind = o.optString("observed", "observed")
                out.add(KpPoint(t, k, kind))
            }
        }
        return out.sortedBy { it.epoch }
    }

    // ------------------------------------------------------------ RainViewer (radar)

    fun radar(): RadarFrames {
        val j = JSONObject(http("https://api.rainviewer.com/public/weather-maps.json"))
        val host = j.optString("host", "https://tilecache.rainviewer.com")
        val past = j.getJSONObject("radar").getJSONArray("past")
        val frames = (0 until past.length()).map {
            val o = past.getJSONObject(it)
            RadarFrame(o.getLong("time"), o.getString("path"))
        }
        return RadarFrames(host, frames)
    }
}
