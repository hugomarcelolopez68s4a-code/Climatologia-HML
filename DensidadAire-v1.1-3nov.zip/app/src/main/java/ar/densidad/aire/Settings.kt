package ar.densidad.aire

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: AppViewModel) {
    var gKey by remember { mutableStateOf(vm.geminiKey) }
    var gModel by remember { mutableStateOf(vm.geminiModel) }
    var cKey by remember { mutableStateOf(vm.apiKey) }
    var cModel by remember { mutableStateOf(vm.aiModel) }
    var saved by remember { mutableStateOf(false) }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel {
            Text("Tema", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m -> Pill(m.label, vm.themeMode == m) { vm.setTheme(m) } }
            }
            Text(
                "Automático sigue el modo claro u oscuro del teléfono.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Panel {
            Text(
                "Análisis de fotos con IA",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AiProvider.values().forEach { p ->
                    Pill(p.label, vm.provider == p) { vm.chooseProvider(p); saved = false }
                }
            }

            if (vm.provider == AiProvider.GEMINI) {
                OutlinedTextField(
                    value = gKey,
                    onValueChange = { gKey = it; saved = false },
                    label = { Text("Clave de API de Gemini") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = gModel,
                    onValueChange = { gModel = it; saved = false },
                    label = { Text("Modelo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { vm.saveGemini(gKey, gModel); saved = true }) { Text("Guardar") }
                Text(
                    "La clave se crea gratis en Google AI Studio. Gemini tiene un nivel gratuito con límites " +
                        "de uso por minuto y por día, y en ese nivel Google puede usar lo que enviás para mejorar " +
                        "sus productos. Si no querés eso, usá una clave con facturación activada o elegí Claude.",
                    color = muted,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                OutlinedTextField(
                    value = cKey,
                    onValueChange = { cKey = it; saved = false },
                    label = { Text("Clave de API de Anthropic") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = cModel,
                    onValueChange = { cModel = it; saved = false },
                    label = { Text("Modelo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { vm.saveAi(cKey, cModel); saved = true }) { Text("Guardar") }
                Text(
                    "La clave se crea en la Claude Console y la API se cobra aparte de tu plan de Claude. " +
                        "Conviene ponerle un límite de gasto.",
                    color = muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            if (saved) Text("Guardado.", color = MaterialTheme.colorScheme.primary)
            Text(
                "La clave queda guardada solo en este teléfono, sin cifrar, y las fotos se envían al proveedor " +
                    "elegido cuando tocás «Analizar». Si el nombre de un modelo deja de existir, cambialo acá.",
                color = muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
