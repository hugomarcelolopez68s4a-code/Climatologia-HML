package ar.densidad.aire

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.SideEffect
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.time.ZoneId
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initOsm(applicationContext)
        enableEdgeToEdge()
        setContent {
            val vm: AppViewModel = viewModel()
            val systemDark = isSystemInDarkTheme()
            val dark = when (vm.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.AUTO -> systemDark
            }
            // Los íconos de las barras del sistema siguen el tema elegido, no el del teléfono.
            SideEffect {
                val transparent = android.graphics.Color.TRANSPARENT
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(transparent)
                    else SystemBarStyle.light(transparent, transparent),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(transparent)
                    else SystemBarStyle.light(transparent, transparent)
                )
            }
            AppTheme(dark) {
                AppRoot(vm)
            }
        }
    }
}

private val TABS = listOf("Resumen", "Viento", "Pronóstico", "Cielo", "Mapa", "Brújula", "Fotos", "Ajustes")

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val owner = LocalLifecycleOwner.current
    // Actualiza al abrir la app y cada 10 minutos mientras está a la vista.
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh()
                delay(10 * 60_000L)
            }
        }
    }

    val now by produceState(nowSec()) {
        while (true) {
            delay(30_000L)
            value = nowSec()
        }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showPlaces by remember { mutableStateOf(false) }
    // Atrás: cierra el diálogo, o vuelve a Resumen; recién en Resumen sale de la app.
    androidx.activity.compose.BackHandler(enabled = showPlaces || tab != 0) {
        if (showPlaces) showPlaces = false else tab = 0
    }

    val f = vm.forecast
    val zone: ZoneId = f?.zone ?: ZoneId.systemDefault()
    val isNow = vm.selectedEpoch == null
    val epoch = vm.selectedEpoch ?: now
    val place = vm.place
    val cond = remember(f, epoch, place) { f?.let { buildConditions(it, epoch, place.elevOverride) } }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { showPlaces = true }, modifier = Modifier.weight(1f)) {
                Text(
                    place.name + "  ▾",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
            TextButton(onClick = { vm.refresh() }) { Text("Actualizar") }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        val upd = vm.lastUpdate
        val status = buildString {
            if (upd != null) append("Actualizado hace " + max(0L, (now - upd) / 60L) + " min")
            else append("Sin datos todavía")
            if (f != null && vm.forecastError != null) append(" · no se pudo actualizar: " + vm.forecastError)
        }
        Text(
            status,
            Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (tab <= 3) TimeBar(vm, epoch, zone, isNow)

        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            TABS.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> SummaryScreen(vm, f, cond)
                1 -> WindScreen(vm, cond)
                2 -> ForecastScreen(vm, f, epoch)
                3 -> SkyScreen(vm, f, epoch, zone)
                4 -> MapScreen(vm, zone, now)
                6 -> PhotosScreen(vm, f, now, zone)
                7 -> SettingsScreen(vm)
                else -> CompassScreen(
                    lat = place.lat,
                    lon = place.lon,
                    altM = cond?.siteElevM ?: (f?.elevationM ?: 0.0),
                    windFrom = cond?.wind?.dirAt(max(vm.aglM, 10.0))
                )
            }
        }
    }

    if (showPlaces) PlacesDialog(vm) { showPlaces = false }
}

@Composable
private fun TimeBar(vm: AppViewModel, epoch: Long, zone: ZoneId, isNow: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            timeStr(epoch, zone, "EEEE d 'de' MMMM, HH:mm") + (if (isNow) "  ·  ahora" else "  ·  hora elegida"),
            style = MaterialTheme.typography.titleSmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("−1 día", false) { vm.stepTime(-86400L) }
            Pill("−1 h", false) { vm.stepTime(-3600L) }
            Pill("Ahora", isNow) { vm.resetTime() }
            Pill("+1 h", false) { vm.stepTime(3600L) }
            Pill("+1 día", false) { vm.stepTime(86400L) }
        }
    }
}

@Composable
fun PlacesDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var mName by remember { mutableStateOf("") }
    var mLat by remember { mutableStateOf("") }
    var mLon by remember { mutableStateOf("") }
    var manualError by remember { mutableStateOf<String?>(null) }

    fun useGps() {
        vm.gpsMessage = "Buscando ubicación…"
        Gps.current(ctx) { loc ->
            if (loc == null) {
                vm.gpsMessage = "No se pudo obtener la ubicación. Revisá que el GPS esté activado."
            } else {
                vm.gpsMessage = null
                vm.addPlace(Place("Mi ubicación (GPS)", loc.latitude, loc.longitude))
                onDismiss()
            }
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) useGps()
        else vm.gpsMessage = "Sin permiso de ubicación. Podés buscar o cargar el lugar a mano."
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Lugar") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Mis lugares", fontWeight = FontWeight.SemiBold)
                vm.places.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            (if (i == vm.selected) "✓ " else "") + p.name,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { vm.selectPlace(i); onDismiss() }
                                .padding(vertical = 8.dp)
                        )
                        if (vm.places.size > 1) {
                            TextButton(onClick = { vm.removePlace(i) }) { Text("Quitar") }
                        }
                    }
                }

                Text("GPS", fontWeight = FontWeight.SemiBold)
                Button(onClick = {
                    if (Gps.hasPermission(ctx)) useGps()
                    else launcher.launch(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    )
                }) { Text("Usar mi ubicación") }
                vm.gpsMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

                Text("Buscar por nombre", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Ciudad, pueblo o paraje") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { vm.search(query) }) { Text("Buscar") }
                vm.geoMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                vm.geoResults.forEach { r ->
                    Text(
                        r.label,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.addPlace(Place(r.label, r.lat, r.lon)); onDismiss() }
                            .padding(vertical = 8.dp)
                    )
                }

                Text("Cargar coordenadas a mano", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = mName, onValueChange = { mName = it },
                    label = { Text("Nombre (opcional)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mLat, onValueChange = { mLat = it },
                    label = { Text("Latitud (ej. -24,19)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mLon, onValueChange = { mLon = it },
                    label = { Text("Longitud (ej. -65,30)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth()
                )
                manualError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Button(onClick = {
                    val la = parseNum(mLat)
                    val lo = parseNum(mLon)
                    if (la == null || lo == null || la < -90.0 || la > 90.0 || lo < -180.0 || lo > 180.0) {
                        manualError = "Latitud entre -90 y 90, longitud entre -180 y 180."
                    } else {
                        manualError = null
                        val name = mName.ifBlank { fmt(la, 3) + ", " + fmt(lo, 3) }
                        vm.addPlace(Place(name, la, lo))
                        onDismiss()
                    }
                }) { Text("Agregar lugar") }
            }
        }
    )
}
