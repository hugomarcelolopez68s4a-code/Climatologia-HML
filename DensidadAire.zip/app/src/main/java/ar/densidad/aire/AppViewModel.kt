package ar.densidad.aire

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var places by mutableStateOf(store.loadPlaces())
        private set
    var selected by mutableIntStateOf(store.loadSelected().coerceIn(0, store.loadPlaces().size - 1))
        private set

    val place: Place get() = places[selected]

    var aglM by mutableDoubleStateOf(store.loadAgl())
        private set
    var windUnit by mutableStateOf(store.loadUnit())
        private set
    var extraHeights by mutableStateOf(store.loadExtra())
        private set

    /** null = "ahora" */
    var selectedEpoch by mutableStateOf<Long?>(null)
        private set

    var forecast by mutableStateOf<Forecast?>(null)
        private set
    var forecastError by mutableStateOf<String?>(null)
        private set
    var kp by mutableStateOf<List<KpPoint>>(emptyList())
        private set
    var kpError by mutableStateOf<String?>(null)
        private set
    var radar by mutableStateOf<RadarFrames?>(null)
        private set
    var radarError by mutableStateOf<String?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var lastUpdate by mutableStateOf<Long?>(null)
        private set

    var geoResults by mutableStateOf<List<GeoResult>>(emptyList())
        private set
    var geoMessage by mutableStateOf<String?>(null)
        private set
    var gpsMessage by mutableStateOf<String?>(null)

    // ---- tema y ajustes de IA

    var themeMode by mutableStateOf(store.loadTheme())
        private set
    var apiKey by mutableStateOf(store.loadKey())
        private set
    var aiModel by mutableStateOf(store.loadModel())
        private set

    fun setTheme(m: ThemeMode) {
        themeMode = m
        store.saveTheme(m)
    }

    fun saveAi(key: String, model: String) {
        apiKey = key.trim()
        aiModel = model.trim().ifBlank { Store.DEFAULT_MODEL }
        store.saveAi(apiKey, aiModel)
    }

    var provider by mutableStateOf(store.loadProvider())
        private set
    var geminiKey by mutableStateOf(store.loadGeminiKey())
        private set
    var geminiModel by mutableStateOf(store.loadGeminiModel())
        private set

    /** Clave del proveedor elegido. */
    val activeKey: String get() = if (provider == AiProvider.GEMINI) geminiKey else apiKey

    fun setProvider(p: AiProvider) {
        provider = p
        store.saveProvider(p)
    }

    fun saveGemini(key: String, model: String) {
        geminiKey = key.trim()
        geminiModel = model.trim().ifBlank { Store.DEFAULT_GEMINI }
        store.saveGemini(geminiKey, geminiModel)
    }

    // ---- fotos

    private val photosDir = File(app.filesDir, "photos").also { it.mkdirs() }

    var photos by mutableStateOf<List<File>>(emptyList())
        private set
    val selectedPhotos = mutableStateListOf<String>()
    var analysis by mutableStateOf<AnalysisState>(AnalysisState.Idle)
        private set

    init {
        reloadPhotos()
    }

    private fun reloadPhotos() {
        photos = (photosDir.listFiles() ?: emptyArray<File>())
            .filter { it.extension == "jpg" && it.length() > 0L }
            .sortedByDescending { it.lastModified() }
    }

    fun newPhotoFile(): File {
        val f = File(photosDir, "foto_" + System.currentTimeMillis() + ".jpg")
        f.createNewFile()
        return f
    }

    fun photoTaken(f: File) {
        if (f.length() > 0L) {
            selectedPhotos.add(f.name)
            analysis = AnalysisState.Idle
            reloadPhotos()
        } else {
            f.delete()
        }
    }

    fun toggleSelected(f: File) {
        if (!selectedPhotos.remove(f.name)) selectedPhotos.add(f.name)
    }

    fun deletePhoto(f: File) {
        f.delete()
        selectedPhotos.remove(f.name)
        analysis = AnalysisState.Idle
        reloadPhotos()
    }

    fun analyze(files: List<File>, dataText: String) {
        val prov = provider
        if (activeKey.isBlank()) {
            analysis = AnalysisState.Failed("Cargá la clave de " + prov.label + " en Ajustes.")
            return
        }
        analysis = AnalysisState.Running
        val key = activeKey
        val model = if (prov == AiProvider.GEMINI) geminiModel else aiModel
        viewModelScope.launch {
            val r = withContextIo {
                val imgs = files.take(4).mapNotNull { Img.toBase64Jpeg(it) }
                if (imgs.isEmpty()) throw IOException("No se pudieron leer las fotos.")
                if (prov == AiProvider.GEMINI) GeminiApi.analyze(key, model, imgs, dataText)
                else ClaudeApi.analyze(key, model, imgs, dataText)
            }
            analysis = r.fold(
                onSuccess = { AnalysisState.Done(it) as AnalysisState },
                onFailure = { AnalysisState.Failed(msg(it)) }
            )
        }
    }

    private var job: Job? = null

    private fun msg(t: Throwable): String = when (t) {
        is UnknownHostException, is ConnectException, is SocketTimeoutException ->
            "Sin conexión a internet o conexión muy lenta."
        else -> t.message ?: t.javaClass.simpleName
    }

    fun refresh() {
        job?.cancel()
        val p = place
        job = viewModelScope.launch {
            loading = true
            try {
                coroutineScope {
                    val fd = async(Dispatchers.IO) { runCatching { Api.forecast(p.lat, p.lon, p.elevOverride) } }
                    val kd = async(Dispatchers.IO) { runCatching { Api.kp() } }
                    val rd = async(Dispatchers.IO) { runCatching { Api.radar() } }

                    var ok = false
                    fd.await().fold(
                        onSuccess = { forecast = it; forecastError = null; ok = true },
                        onFailure = { forecastError = msg(it) }
                    )
                    kd.await().fold(
                        onSuccess = { kp = it; kpError = null; ok = true },
                        onFailure = { kpError = msg(it) }
                    )
                    rd.await().fold(
                        onSuccess = { radar = it; radarError = null; ok = true },
                        onFailure = { radarError = msg(it) }
                    )
                    if (ok) lastUpdate = nowSec()
                }
            } finally {
                loading = false
            }
            // Si la hora elegida quedó fuera del rango del pronóstico, vuelve a "ahora".
            val f = forecast
            val sel = selectedEpoch
            if (f != null && sel != null && f.time.isNotEmpty() &&
                (sel < f.time.first() || sel > f.time.last())
            ) selectedEpoch = null
        }
    }

    // ---- lugares

    fun selectPlace(i: Int) {
        if (i !in places.indices) return
        selected = i
        store.saveSelected(i)
        forecast = null
        forecastError = null
        refresh()
    }

    fun addPlace(p: Place) {
        val list = places.filter { it.name != p.name } + p
        places = list
        store.savePlaces(list)
        selectPlace(list.indexOfFirst { it.name == p.name })
    }

    fun removePlace(i: Int) {
        if (places.size <= 1 || i !in places.indices) return
        val list = places.filterIndexed { idx, _ -> idx != i }
        places = list
        store.savePlaces(list)
        selectPlace(0)
    }

    fun setElevation(v: Double?) {
        val list = places.mapIndexed { i, p -> if (i == selected) p.copy(elevOverride = v) else p }
        places = list
        store.savePlaces(list)
        forecast = null
        refresh()
    }

    // ---- ajustes

    fun updateAgl(v: Double) {
        aglM = v
        store.saveAgl(v)
    }

    fun setUnit(u: WindUnit) {
        windUnit = u
        store.saveUnit(u)
    }

    fun setExtra(s: String) {
        extraHeights = s
        store.saveExtra(s)
    }

    // ---- hora elegida

    fun stepTime(deltaSec: Long) {
        val f = forecast ?: return
        if (f.time.isEmpty()) return
        val base = selectedEpoch ?: nowSec()
        val target = ((base + deltaSec) / 3600L) * 3600L
        selectedEpoch = target.coerceIn(f.time.first(), f.time.last())
    }

    fun resetTime() {
        selectedEpoch = null
    }

    // ---- búsqueda de lugares por nombre

    fun search(query: String) {
        if (query.isBlank()) return
        geoMessage = "Buscando…"
        viewModelScope.launch {
            val r = withContextIo { Api.geocode(query) }
            r.fold(
                onSuccess = {
                    geoResults = it
                    geoMessage = if (it.isEmpty()) "Sin resultados." else null
                },
                onFailure = {
                    geoResults = emptyList()
                    geoMessage = msg(it)
                }
            )
        }
    }

    private suspend fun <T> withContextIo(block: () -> T): Result<T> =
        kotlinx.coroutines.withContext(Dispatchers.IO) { runCatching(block) }
}

/** Alturas extra ingresadas a mano ("250, 400"), en metros sobre el suelo. */
fun parseHeights(s: String): List<Double> =
    s.split(',', ';', ' ')
        .mapNotNull { parseNum(it) }
        .filter { it > 0.0 && it <= 6000.0 }
        .distinct()
        .sorted()
